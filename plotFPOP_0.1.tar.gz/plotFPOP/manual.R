
pack <- "plotFPOP"
path <- find.package(pack)
path
system(paste(shQuote(file.path(R.home("bin"), "R")),"CMD", "Rd2pdf", shQuote(path)))

check(cleanup = FALSE,args = c('--no-examples'),manual = TRUE,path = path)
